<button data-bs-toggle="modal" data-bs-target="#plantelligenceBot"
    class="btn btn-light p-2 text-blue text-center d-flex justify-content-center align-items-center flex-column mt-2"
    style="aspect-ratio:1; border-radius: 16px;">
    <x-brain-svg />
    <div class="mt-1">
        Plantelligence AI
    </div>
</button>