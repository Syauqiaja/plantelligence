<div class="bg-gray text-white">
    <div class="h-100 p-3">
        <h5 class="text-center my-3">Peta Konsep</h5>
        <div class="mt-5 h-100 w-100">
            <img class="w-100" src="{{ asset('images/peta-konsep.png') }}" alt="" style="object-fit: contain;">
        </div>
    </div>
</div>