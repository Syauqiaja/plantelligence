<!-- Header -->
<div class="modal-header border-0 position-relative bg-gradient-blue">
    {{ $slot }}
    <button type="button" class="btn-close btn-close-white position-absolute" data-bs-dismiss="modal" aria-label="Close"
        style="top: 1rem; right: 1rem;"></button>
</div>