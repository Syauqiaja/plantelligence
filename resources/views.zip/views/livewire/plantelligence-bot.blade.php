<div class="modal-content border-0 shadow-lg">
    <x-modal.modal-header>
        <div class="w-100 text-center text-white fw-bold">
            <h5 class="h4 text-center">Plantelligence AI</h5>
        </div>
    </x-modal.modal-header>
    <div class="modal-body p-3">
    </div>
</div>