<div class="bg-primary">
    <div class="position-relative h-100 pt-3" id="cover-page" style="background-image: url({{ asset('images/cover.png') }}); background-size: 100% 100%;">
        
    </div>
</div>